export class ProductFilter {
}
