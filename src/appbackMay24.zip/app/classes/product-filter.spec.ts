import { ProductFilter } from './product-filter';

describe('ProductFilter', () => {
  it('should create an instance', () => {
    expect(new ProductFilter()).toBeTruthy();
  });
});
