import { Route } from '@angular/router';
import { SettingsComponent } from './settings.component';
export const SettingsRoutes: Route[] = [
  {
    path: '',
    component: SettingsComponent
  }
];
