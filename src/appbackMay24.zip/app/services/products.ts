export interface Products {
  prodID: string;
  productName: string;
  productCost: string;
  productLogo: string;
  productMiniLogo: string;
  id: string;
  name: string;
  price: string;
  colors: Object[];
}
/*export const Products : Products;*/
