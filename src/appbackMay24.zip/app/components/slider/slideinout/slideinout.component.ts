import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slideinout',
  templateUrl: './slideinout.component.html',
  styleUrls: ['./slideinout.component.css']
})
export class SlideinoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
