import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ButtonComponent } from './button/button.component';
import { LogoComponent } from './logo/logo.component';
import { NameComponent } from './name/name.component';
import { SlideinoutComponent } from './slider/slideinout/slideinout.component';
import { PublicProductsComponent } from './products/publicproducts.component';

@NgModule({
 /* , PublicproductsComponent */
  declarations: [NameComponent, LogoComponent, ButtonComponent, SlideinoutComponent ],
  exports: [NameComponent, LogoComponent, ButtonComponent, SlideinoutComponent ],
  imports: [CommonModule]
})
export class ComponentsModule {}
