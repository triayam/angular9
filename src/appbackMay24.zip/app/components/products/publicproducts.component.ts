import {AfterViewInit, Component, OnInit, Input} from '@angular/core';
import { ProductService} from '../../services/product.service';
import {Product , ProductColor} from '../../classes/product';
import {Products} from '../../services/products';

@Component({
  selector: 'app-spa-products',
  templateUrl: './publicproducts.component.html',
  styles: []
})
export class PublicProductsComponent implements OnInit , AfterViewInit {

  private productService: ProductService;
  public products: Product[] = [];
  public productsTwo: Product[] = [];
  public cols: ProductColor[] = [];
  public  myObject = {} as Product;

  constructor(productService: ProductService) {
    this.productService = productService;
  }

  ngOnInit(): void {
    const prd = this.productService.getProducts();
    prd.map( value => {
        value.colors.forEach((value1, idx) => {
          this.cols.push(<ProductColor>value1);
        });
        return  <Product>{
          id: Number(value.id).valueOf(),
          name: value.name,
          price: Number(value.price).valueOf(),
          currency: '',
          colors: this.cols, // [ <ProductColor> value.colors[0] , <ProductColor> value.colors[1] ];
          picture: '',
          prodID: value.prodID,
          productName: value.productName,
          productCost: value.productCost,
          productLogo: value.productLogo,
          productMiniLogo: value.productMiniLogo

        };
        this.cols = [];
      }
    ).forEach(p => {
      console.log(' typeOf P ' + typeof p);
      this.products.push(p);
    });
  }

  ngAfterViewInit(): void {
    // throw new Error("Method not implemented.");npm
      const prd = this.productService.getProducts();
     // this.cost = prd[0].productCost;

      this.productsTwo = [
      <Product>{id: 1, name: 'Blue item', price: 123.09, colors: ['blue'],
        prodID:  '24123', productName:  'Shirt', productCost: '23' , productLogo:  'assets/img/products/t-shirt.JPG'},
      <Product>{id: 2, name: 'Green and gray', price: 99.09, colors: ['green', 'gray']   ,
      prodID:  '24123', productName:  'Shirt', productCost: '23' , productLogo:  'assets/img/products/sweat-shirt.JPG'}
      ];

      console.log(' productsTwo ' + this.productsTwo);
      console.log(' productsTwo JSON ' + JSON.stringify(this.productsTwo));
      if (Array.isArray(prd)) {
        console.log('prd is array  ' );
      } else { /* We are working with object */
        Object.keys(prd).forEach((key) => {
          console.log('prd is not array ' );
          /* Here you can iterate over each key in object */
        });
      }

     // this.products = this.productsTwo;
    console.log('products array ' + this.products);
    // this.products = this.productsTwo;
    console.log('rpoducts aaray ' + JSON.stringify(this.products));
    console.log('product ' + JSON.stringify(prd));
 }




}
