import {ChangeDetectionStrategy, Component, Input, OnInit} from '@angular/core';
import {Product, ProductFilter} from '../../../classes/product';

@Component({
  selector: 'app-spa-product-list',
  templateUrl: './product-list.component.html',
  styles: ['product-list.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductListComponent implements OnInit {

  constructor() { }
  @Input() public products: Product[] = [];

  public readonly filters: ProductFilter [] = [
    <ProductFilter>{color: 'blue'},
    <ProductFilter>{color: 'green'},
    <ProductFilter>{color: 'gray'}
  ];
  public activeFilters: ProductFilter[] = [];
  userColor;


  ngOnInit(): void {
  }
  public itemsAfterFilter(): Product[] {
    return this.products.filter(
      (product: Product) => {
         const matchesActiveFilter: boolean = this.activeFilters.reduce(
           (previousValue, currentValue) => {
             if (product.colors.includes(currentValue.color)) {
                return previousValue && true;
             } else {
               return false;
             }
           }, true);
            return matchesActiveFilter;
          });

      }
    public updateActivatedFilters(filters: ProductFilter[]) {
     this.activeFilters = filters;
    }

}
